# Vegas AI

A simple Python library for picking a random winner.

## Installation
```bash
pip install vegas_ai
